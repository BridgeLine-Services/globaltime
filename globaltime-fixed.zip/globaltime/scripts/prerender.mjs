// scripts/prerender.mjs
//
// Runs after `vite build` (see "postbuild" in package.json). Vite's build
// output is a pure client-side SPA: dist/index.html has an empty <div
// id="root">, and every route's real content only appears after React runs
// in the browser. Crawlers that don't execute JS (and quality classifiers
// that weight the initial HTML heavily, which is the working theory for the
// AdSense "low value content" rejection here) see essentially nothing.
//
// This script spins up a local static server for the built dist/ folder,
// visits every real route in a headless browser, waits for React to finish
// rendering, and writes the resulting fully-rendered HTML back into
// dist/<route>/index.html. main.tsx then hydrates onto that markup instead
// of wiping it out with a fresh client render (see the hydrateRoot check
// added there).
//
// Requires two new devDependencies — install before running:
//   npm install -D puppeteer serve-handler
//
// This script has NOT been run/tested in this environment (no network
// access), so treat it as a starting point: run `npm run build` locally,
// check a couple of the generated dist/time/<slug>/index.html files by eye
// (search for the country name / hub-city text to confirm it's really
// there), and adjust selectors/timeouts if anything doesn't match your
// actual DOM.

import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import handler from 'serve-handler';
import puppeteer from 'puppeteer';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.join(__dirname, '..');
const DIST_DIR = path.join(ROOT_DIR, 'dist');
const PORT = 4173;

// Routes that exist regardless of data. Keep this in sync with src/App.tsx —
// there's no automatic discovery here, on purpose, so a route typo shows up
// as a missing file rather than a silent skip.
const STATIC_ROUTES = [
  '/',
  '/world',
  '/games',
  '/blog',
  '/legal',
  '/weather',
  '/on-this-day',
  '/faq',
  '/sky',
  '/storms',
  '/collections',
  '/games/reaction',
  '/games/memory',
  '/games/clicker',
  '/games/puzzle',
  '/games/runner',
  '/games/typing',
  '/games/quiz',
  '/games/snake',
  '/games/color',
  '/games/mathblitz',
  '/games/flagquiz',
  '/games/capitals',
  '/games/simon',
  '/games/numbermemory',
  '/games/wordscramble',
  '/games/tictactoe',
  '/games/chronoword',
  '/games/countdown',
  '/games/minesweeper',
];

// Deliberately excluded: /x-admin-9f3a (not a public page — robots.txt
// already disallows it, and prerendering it would just bake an internal
// tool into a publicly indexable file).

async function getCountrySlugs() {
  const src = await readFile(
    path.join(ROOT_DIR, 'src', 'data', 'countries.ts'),
    'utf-8'
  );
  const slugs = [...src.matchAll(/slug:\s*'([a-z0-9-]+)'/g)].map((m) => m[1]);
  return [...new Set(slugs)];
}

function startServer() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) =>
      handler(req, res, {
        public: DIST_DIR,
        rewrites: [{ source: '**', destination: '/index.html' }],
      })
    );
    server.listen(PORT, () => resolve(server));
  });
}

async function main() {
  const countrySlugs = await getCountrySlugs();
  const routes = [...STATIC_ROUTES, ...countrySlugs.map((slug) => `/time/${slug}`)];

  console.log(`Prerendering ${routes.length} routes (${countrySlugs.length} country pages)...`);

  const server = await startServer();
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  let failures = 0;

  for (const route of routes) {
    try {
      const url = `http://localhost:${PORT}${route}`;
      await page.goto(url, { waitUntil: 'networkidle0', timeout: 30000 });
      // #main-content is the <main> wrapper in App.tsx — waiting for it
      // confirms React has mounted and the route's page component rendered.
      await page.waitForSelector('#main-content h1, #main-content h2', { timeout: 10000 });

      const html = await page.content();
      const outDir = route === '/' ? DIST_DIR : path.join(DIST_DIR, route);
      await mkdir(outDir, { recursive: true });
      await writeFile(path.join(outDir, 'index.html'), html, 'utf-8');
      console.log(`  ✓ ${route}`);
    } catch (err) {
      failures += 1;
      console.error(`  ✗ ${route} — ${err.message}`);
    }
  }

  await browser.close();
  server.close();

  if (failures > 0) {
    console.error(`\nPrerender finished with ${failures} failed route(s). Fix these before deploying —`);
    console.error('a failed route just keeps its original empty-shell index.html, which is the exact problem this script exists to solve.');
    process.exitCode = 1;
  } else {
    console.log('\nPrerender complete — all routes now have real HTML content.');
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
